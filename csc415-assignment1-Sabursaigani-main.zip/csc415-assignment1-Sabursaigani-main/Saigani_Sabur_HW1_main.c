/**************************************************************
* Class:  CSC-415-0# Spring 2022
* Name:Sabur Saigani
* Student ID:921794806
* GitHub Name:Sabursaigani
* Project: Assignment 1 – Command Line Arguments
*
* File: <Saigani_Sabur_HW1_main.c>
*
* Description:
*
**************************************************************/

#include <stdio.h>

int main(int argc, char* argv[])
{
   // declare an integer variable i to be used in the for loop
   int i;
   // display message about the number of arguments to the program
   printf("There were %d arguments on the command line.\n", argc);
   // display the arguments one by one using a for loop
   for (i=0; i<argc; i++)
   {
       printf("Argument %02d:\t%s\n", i, argv[i]);
   }
   // return successful code execution
   return 0;
}
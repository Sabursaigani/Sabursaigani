/**************************************************************
* Class:  CSC-415-0# Spring 2022
* Name: Sabur Saigani
* Student ID: 921794806
* GitHub UserID: Sabursaigani
* Project: Assignment 3 – Simple Shell
*
* File: Saigani_Sabur_HW3_main.c
*
* Description:
*
**************************************************************/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


#define MAX_LIMIT 180

/**
 * Helper function to trim the leading and trailing whitespaces.
 * @param  str command string
 * @return     trimmed string
 */
char *trimwhitespace(char *str)
{
	char *end;

	// Trim leading space
	while(isspace((unsigned char)*str)) str++;

	if(*str == 0)  // All spaces?
		return str;

	// Trim trailing space
	end = str + strlen(str) - 1;
	while(end > str && isspace((unsigned char)*end)) end--;

	// Write new null terminator character
	end[1] = '\0';

	return str;
}

int main(int argc, char const *argv[])
{
	char* Prompt;
	// getting the Prompt value.
	if (argc < 2)
	{
		Prompt =  ">";
	}
	else
	{
		Prompt = argv[1];
	}

	char command[MAX_LIMIT];

	// to hold the status of command run (child process).
	int status;

	// keeping in loop till end of file/input.
	while (!feof(stdin))
	{
		printf("%s", Prompt);
		fgets(command, MAX_LIMIT, stdin);
		char* trimmedCommand = trimwhitespace(command);

		// if empty line/command.
		if (strlen(trimmedCommand) == 0)
		{
			printf("Encountered empty line as input command, skipping...\n");
			continue;
		}
		// if exit command.
		else if (strcmp(trimmedCommand, "exit") == 0)
		{
			exit(0);
		}

		// creating child process for running command.
		if (fork() == 0)
		{
			// getting the argument_list from command.
			char splitted[MAX_LIMIT][MAX_LIMIT];
			int index = 0;

			int i = 0, j = 0;
			for (i = 0; i <= (strlen(trimmedCommand)); i++) {
			    if (trimmedCommand[i] == ' ' || trimmedCommand[i] == '\0') {
			        splitted[index][j] = '\0';
			        index++;
			        j = 0;
			    }
			    else {
			        splitted[index][j] = trimmedCommand[i];
			        j++;
			    }
			}

			// putting the argument into null terminating list.
			char* argument_list[index+1];
			for (i = 0; i < index; i++)
			{
				argument_list[i] = splitted[i];
			}
			argument_list[index] = NULL;

			// running command using execvp.
			int status_code = execvp(argument_list[0], argument_list);
			exit(0);
		}
		else
		{
			// waiting for status and pid of child in parent.
			int pid = wait(&status);
			printf("Child %d, exited with %d\n", pid, status);
		}

	}

	return 0;
}
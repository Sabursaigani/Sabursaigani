/**************************************************************
* Class:  CSC-415-0# Spring 2022
* Name: Sabur Saigani
* Student ID: 921794806
* GitHub UserID: Sabursaigani
* Project: Assignment 4 – Word Blast
*
* File: Saigani_Sabur_HW4_main.c
*
* Description:
*
**************************************************************/


#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>


// You may find this Useful
char * delim = "\"\'.“”‘’?:;-,—*($%)! \t\n\x0A\r";

// structure for counting the words.
struct Word {
    char word[40];
    int freq;
};

struct Word wordFreqs[20000];
int sizeOfArray = 0;

int threadCount;
char* filename;

int fd;
size_t fileSize;
size_t chunk;

pthread_mutex_t critical_lock = PTHREAD_MUTEX_INITIALIZER;


void processWord(char* word) {
    int added = 0;
    for (int i = 0; i < sizeOfArray; i++) {
        if (strcmp(wordFreqs[i].word, word) == 0) {
            pthread_mutex_lock(&critical_lock);
            wordFreqs[i].freq += 1;
            added = 1;
            pthread_mutex_unlock(&critical_lock);
            break;
        }
    }

    if (added == 0) {
        pthread_mutex_lock(&critical_lock);
        strcpy(wordFreqs[sizeOfArray].word, word);
        wordFreqs[sizeOfArray].freq = 1;
        sizeOfArray++;
        pthread_mutex_unlock(&critical_lock);
    }
}

void* processFile(void *arg) {

    char* buffer = (char *) malloc(chunk);

    off_t* bufferEnd = (off_t*)arg;
    off_t bufferStartOffset = *bufferEnd - chunk;
    pread(fd, buffer, chunk, bufferStartOffset);
    char* token;
    while ((token = strtok_r(buffer, delim, &buffer))) {
        if (strlen(token) >= 6) {
            processWord(token);
        }
    }
    pthread_exit(NULL);
}

void bubble_sort() {
    for (int i = 0; i < sizeOfArray; i++) {
        for (int j = 0; j < sizeOfArray - 1 - i; j++) {
            if (wordFreqs[j].freq > wordFreqs[j+1].freq) {
                // printf("Before switching %s,%d - %s,%d\n", wordFreqs[j].word, wordFreqs[j].freq, wordFreqs[j+1].word, wordFreqs[j+1].freq);
                struct Word temp = wordFreqs[j];
                wordFreqs[j] = wordFreqs[j+1];
                wordFreqs[j+1] = temp;
                // printf("After switching %s,%d - %s,%d\n", wordFreqs[j].word, wordFreqs[j].freq, wordFreqs[j+1].word, wordFreqs[j+1].freq);
            }
        }
    }
}

int main (int argc, char *argv[])
    {
    //***TO DO***  Look at arguments, open file, divide by threads
    //             Allocate and Initialize and storage structures

    filename = argv[1];
    threadCount = atoi(argv[2]);

    printf("%s, %d\n", filename, threadCount);

    fd = open(filename, O_RDONLY);

    off_t current = lseek(fd, 0, SEEK_CUR);
    fileSize = lseek(fd, 0, SEEK_END);
    chunk = (fileSize / threadCount);
    lseek(fd, current, SEEK_SET);

    off_t* bufferArray[threadCount];
    for (int i = 0; i < threadCount; i++) {
        bufferArray[i] = (off_t*)((i+1) * chunk);
    }

    //**************************************************************
    // DO NOT CHANGE THIS BLOCK
    //Time stamp start
    struct timespec startTime;
    struct timespec endTime;

    clock_gettime(CLOCK_REALTIME, &startTime);
    //**************************************************************
    // *** TO DO ***  start your thread processing
    //                wait for the threads to finish

    pthread_t tids[threadCount];

    for (int i = 0; i < threadCount; i++) {
        pthread_create(&tids[i], NULL, processFile, &bufferArray[i]);
    }

    for (int i = 0; i < threadCount; i++) {
        pthread_join(tids[i], NULL);
    }

    // ***TO DO *** Process TOP 10 and display

    bubble_sort();

    int number = 1;
    for (int i = sizeOfArray-1; i > sizeOfArray-11; i--) {
        printf("Number %d is %s with a count of %d\n", number, wordFreqs[i].word, wordFreqs[i].freq);
        number++;
    }

    //**************************************************************
    // DO NOT CHANGE THIS BLOCK
    //Clock output
    clock_gettime(CLOCK_REALTIME, &endTime);
    time_t sec = endTime.tv_sec - startTime.tv_sec;
    long n_sec = endTime.tv_nsec - startTime.tv_nsec;
    if (endTime.tv_nsec < startTime.tv_nsec)
        {
        --sec;
        n_sec = n_sec + 1000000000L;
        }

    printf("Total Time was %ld.%09ld seconds\n", sec, n_sec);
    //**************************************************************

    close(fd);

    // ***TO DO *** cleanup
    }


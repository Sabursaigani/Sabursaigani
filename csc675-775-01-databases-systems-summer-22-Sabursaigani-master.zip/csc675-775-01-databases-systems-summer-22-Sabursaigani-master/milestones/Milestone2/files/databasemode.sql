-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema bank
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `bank` ;

-- -----------------------------------------------------
-- Schema bank
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `bank` DEFAULT CHARACTER SET utf8 ;
USE `bank` ;




-- -----------------------------------------------------
-- Table `Person`
-- -----------------------------------------------------


Create Table Person(
	Person_ID INT NOT NULL,
    Full_Name varchar(255),
    Address varchar(255),
    DOB Date,
    Salary INT,
    Gender varchar(20),
    Contact_No INT,
    Email Varchar(60),
    Nationality varchar(50),
    Primary Key (Person_ID)
);


-- -----------------------------------------------------
-- Table `INsurance`
-- -----------------------------------------------------



Create Table Insurance (
	In_No INT NOT NULL,
    Type varchar(255),
    Amount int,
    Start_Date Date,
    End_Date Date,
    Primary Key (In_No)
);


-- -----------------------------------------------------
-- Table `Locker`
-- -----------------------------------------------------


Create Table Locker(
	Locker_ID INT NOT NULL,
    Size varchar(20),
    Start_Date Date,
    Primary Key (Locker_ID)
);

-- -----------------------------------------------------
-- Table `Loan_Payment`
-- -----------------------------------------------------


Create Table Loan_Payment(
	Payment_No INT NOT NULL,
    Status varchar(255),
    Loan_Date Date,
    Amount INT,
    Primary Key (Payment_No)
);

-- -----------------------------------------------------
-- Table `Account_Type`
-- -----------------------------------------------------



Create Table Account_Type(
	Acc_Type_Code varchar(10) NOT NULL,
    Min_Balance_Limit INT,
    Description varchar(255),
    Primary Key (Acc_Type_Code)
);


-- -----------------------------------------------------
-- Table `Interest`
-- -----------------------------------------------------


Create Table Interest(
	Interest_ID INT NOT NULL,
    Rate iNT,
    Balance INT,
    Start_Date date,
    Primary Key (Interest_ID)
);

-- -----------------------------------------------------
-- Table `Credit_card`
-- -----------------------------------------------------


Create Table Credit_Card(
	Credit_Card_No INT NOT NULL,
    Limitt int,
    Issue_Date Date, 
    Expiry_Date Date,   
    Primary Key (Credit_Card_No)
);


-- -----------------------------------------------------
-- Table `Debit_Card`
-- -----------------------------------------------------


Create Table Debit_Card(
	Debit_Card_No INT NOT NULL,
    Limitt int,
    Issue_Date Date,
     Expiry_Date Date,
   
    Primary Key (Debit_Card_No)
);

-- -----------------------------------------------------
-- Table `Prepaid_Card`
-- -----------------------------------------------------


Create Table Prepaid_Card(
	Prepaid_Card_No INT NOT NULL,
	Limitt int,
    Issue_Date Date,
     Expiry_Date Date,
   
    Primary Key (Prepaid_Card_No)
);
-- -----------------------------------------------------
-- Table `Bank`
-- -----------------------------------------------------


Create Table Bank(
	BCode varchar(10) NOT NULL,
    No_of_Employees INT,
    Name varchar(100),
    Address varchar(255),
    Primary Key (BCode)
);

-- -----------------------------------------------------
-- Table `Log`
-- -----------------------------------------------------



Create Table Log(
	Log_ID INT NOT NULL,
	Type varchar(10),
    Login_DateTime Date,
    Logout_DateTime Date,
    Primary Key (Log_ID)
);


-- -----------------------------------------------------
-- Table `Loan`
-- -----------------------------------------------------


Create Table Loan(
	Loan_ID INT NOT NULL,
    Payment_No INT,
    Start_Date date,
    Duration INT,
    Type varchar(20),
    Amount INT,
    Primary Key (Loan_ID),
    Foreign Key (Payment_No) References Loan_Payment(Payment_No)
);
-- -----------------------------------------------------
-- Table `Branch`
-- -----------------------------------------------------



Create Table Branch(
	Branch_Code varchar(10) NOT NULL,
    Bcode varchar(10),
    Name varchar(20),
    Address varchar(100),
    No_of_Employees INT,
    Primary Key(Branch_Code),
    Foreign Key (BCode) References Bank(BCode)
);


-- -----------------------------------------------------
-- Table `Employee`
-- -----------------------------------------------------


Create Table Employee(
	Employee_ID INT,
	Branch_Code varchar(10),
	Foreign Key (Employee_ID) References Person(Person_ID),
	Foreign Key (Branch_Code) References Branch (Branch_Code)
);    
-- -----------------------------------------------------
-- Table `Customer`
-- -----------------------------------------------------


Create Table Customer(
	Cust_ID INT,
	In_No INT,
	Loan_ID INT,
	Locker_ID INT,
	Foreign Key (Cust_ID) References Person(Person_ID),
	Foreign Key (In_No) References Insurance (In_No),
	Foreign Key (Loan_ID) References Loan(Loan_ID),
	Foreign Key (Locker_ID) References Locker (Locker_ID)
);
-- -----------------------------------------------------
-- Table `Transaction`
-- -----------------------------------------------------



Create Table Transaction(
	Trans_No INT NOT NULL,
	Log_ID INT,
	Credit_Card_No INT,
	Prepaid_Card_No INT,
	Debit_Card_No INT,
	Status varchar(20),
	Trans_Type varchar(20),
	Amount INT,
	Primary key (Trans_No),
	Foreign Key (Log_ID) References Log(Log_ID),
	Foreign Key (Credit_Card_No) References Credit_Card(Credit_Card_No),
	Foreign Key (Prepaid_Card_No) References Prepaid_Card(Prepaid_Card_No),
	Foreign Key (Debit_Card_No) References Debit_Card(Debit_Card_No)
	
);

-- -----------------------------------------------------
-- Table `account`
-- -----------------------------------------------------


Create Table Account(
	Acc_No INT NOT NULL,
	Cust_ID INT,
	Branch_Code varchar(10),
	Acc_Type_Code varchar(10),
	Interest_ID INT,
	Trans_No INT,
	Open_Date Date,
	Status INT,
	Balance INT,
	Primary Key (Acc_No),
	Foreign Key (Cust_ID) References Customer(Cust_ID),
	Foreign Key (Branch_Code) References Branch(Branch_Code),
	Foreign Key (Interest_ID) References Interest(Interest_ID),
	Foreign Key (Trans_No) References Transaction(Trans_No)
);







    
    
 



    
    
 

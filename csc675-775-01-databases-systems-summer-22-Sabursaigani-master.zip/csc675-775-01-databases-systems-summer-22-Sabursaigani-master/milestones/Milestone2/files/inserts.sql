Use Bank;

Insert into Person values (11 , 'John Smith' , 'London' ,'2013-09-23' , 50000 , 'Male' , 0324233 , 'john@gmail.com', 'British' );
Insert into Person values (12 , 'will Smith' , 'USA' ,'2019-09-23' , 60000 , 'Male' , 546765233 , 'will@gmail.com', 'Amercian' );
Insert into Person values (13 , 'Tom Cruse' , 'USA' ,'2020-09-23' , 500000 , 'Male' ,8793233 , 'tom@gmail.com', 'American' );
Insert into Person values (14 , 'Anna' , 'London' ,'2013-09-23' , 90000 , 'Female' , 0324233 , 'anna@gmail.com', 'British' );
Insert into Person values (15 , 'Kylie Jenner' , 'USA' ,'2019-09-23' , 80000 , 'Female' , 123765233 , 'kylie@gmail.com', 'Amercian' );
Insert into Person values (16 , 'Kurdashain' , 'USA' ,'2020-09-23' , 50000 , 'Female' ,9643233 , 'kur@gmail.com', 'American' );

Insert into Insurance values (20 , 'Health' , 500 , '2022-03-03' , '2022-04-03');
Insert into Insurance values (21 , 'Health' , 700 , '2022-03-03' , '2022-04-03');
Insert into Insurance values (22 , 'Education' , 5000 , '2020-03-03' , '2022-03-03');

insert into Locker values (31, '20x30' , '2021-01-01');
insert into Locker values (32, '15x50' , '2021-02-02');
insert into Locker values (33, '25x50' , '2021-03-03');


insert into Loan_Payment values (41, 'Pending' , '2022-03-05' , 600);
insert into Loan_Payment values (42, 'Active' , '2022-05-05' , 800);
insert into Loan_Payment values (43, 'Completed' , '2022-08-05' , 900);



Insert into Account_Type values (51 , 100 , 'This is saving Account');
Insert into Account_Type values (52 , 20 , 'This is Current Account');
Insert into Account_Type values (53 , 200 , 'This is Trading Account');


Insert into Interest values (61, 5 , 500 , '2020-05-02');
Insert into Interest values (62, 7 , 800 , '2021-05-02');
Insert into Interest values (63, 9 , 200 , '2022-05-02');


Insert into Credit_Card values (71 , 20000 , '2015-01-01' , '2019-01-01');
Insert into Credit_Card values (72 , 25000 , '2016-01-01' , '2020-01-01');
Insert into Credit_Card values (73 , 30000 , '2017-01-01' , '2021-01-01');


Insert into Debit_Card values (81 , 20000 , '2015-01-01' , '2019-01-01');
Insert into Debit_Card values (82 , 25000 , '2016-01-01' , '2020-01-01');
Insert into Debit_Card values (83 , 30000 , '2017-01-01' , '2021-01-01');


Insert into Prepaid_Card values (91 , 2000 , '2015-01-01' , '2019-01-01');
Insert into Prepaid_Card values (92 , 2500 , '2016-01-01' , '2020-01-01');
Insert into Prepaid_Card values (93 , 3000 , '2017-01-01' , '2021-01-01');


Insert into Bank values ('B101' , 50 , 'Bank of England'  , 'London');
Insert into Bank values ('B102' , 80 , 'Bank of USA'  , 'New York');
Insert into Bank values ('B103' , 100 , 'Bank of UK'  , 'Wales');


Insert into Log values (101 , 'Saving' , '2022-03-01' , '2022-03-02');
Insert into Log values (102 , 'Current' , '2022-04-01' , '2022-04-02');
Insert into Log values (103 , 'Trading' , '2022-05-01' , '2022-05-02');


Insert into Loan values (111 , 41 ,'2022-03-05' , 5 , 'Health' , 5000 );
Insert into Loan values (112 , 42 ,'2022-05-05' , 8 , 'Education' , 5000 );
Insert into Loan values (113 , 43 ,'2022-08-05' , 10 , 'Health' , 5000 );


Insert into Branch values ('BC101' , 'B101' , 'Bank Of England' ,'England' , 50 );
Insert into Branch values ('BC102' , 'B102' , 'Bank Of USA' ,'England' , 80 );
Insert into Branch values ('BC103' , 'B103' , 'Bank Of UK' ,'Wales' , 100 );


Insert into Employee values (11 , 'BC101');
Insert into Employee values (12 , 'BC102');
Insert into Employee values (13 , 'BC103');


Insert into Customer values (14 , 20 , 111, 31);
Insert into Customer values (15 , 21 , 112 , 32);
Insert into Customer values (16 , 22 , 113, 33);


Insert into Transaction values (121 ,101, 71, 91 , 81 , 'Pending' , 'Saving' , 5000 );
Insert into Transaction values (122 ,102, 72, 92 , 82 , 'Pending' , 'Trading' , 9000 );
Insert into Transaction values (123 ,103, 73, 93 , 83 , 'Completed' , 'Current' , 7000 );


Insert into Account values (131 , 14 , 'BC101' , 'AC101' , 61 , 121 , '2022-03-01' , 1 , 5000);
Insert into Account values (132 , 15 , 'BC102' , 'AC102' , 62 , 122 , '2022-04-01' , 1 , 9000);
Insert into Account values (133 , 16 , 'BC103' , 'AC103' , 63 , 123 , '2022-04-01' , 0 , 7000);





    
    
 

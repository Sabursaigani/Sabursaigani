# Files that this folder must contain

1. eer.mwb
2. databasemodel.sql
3. inserts.sql
4. tests.sql
5. BusinessRequirements.md
6. ERDMod.md (only if you would like your ERD be revised)


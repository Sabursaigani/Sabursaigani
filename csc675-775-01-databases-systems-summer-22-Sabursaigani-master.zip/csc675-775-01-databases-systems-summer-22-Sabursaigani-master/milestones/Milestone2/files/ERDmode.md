I added more strong enities such as logs, prepaid_card, person, and locker
I also added some assotiation
I also made sure that 1 enity is not connect to more than 2 entitys.

   
  --  Find the Person that are Customer in our database 
    Select  p.* 
    From Person p , Customer c 
    where p.Person_ID = c.Cust_ID 
    Group by p.Person_ID ;
    
 --   Find the Person that are Employees in our database 
    Select  p.* 
    From Person p , Employee e 
    where p.Person_ID = e.Employee_ID 
    Group by p.Person_ID ;
    
--    SHow all interset in database 
    select * from Interests;
    
 --   Show all transactions that has been made so far 
    Select * from Transactions;
    
--    Display all the transaction done by Credit Card
    Select * from Credit_Card
    
    
--    Display all the transaction done by Debit Card
    Select * from Debit_Card
    
--    Display all the transaction done by PrePaid Card
    Select * from Prepaid_Card
    
    
 --   List the bank that has more than 50 employees working in them
    select * from Bank where No_of_Employees > 50	
    
 --   Find the Customer whose belongs to London and have balance greater than 1000 in their account
    Select p.Full_name , a.Balance
    From Person p , Customer c , Account a 
    where p.Person_ID = c.Cust_ID and a.cust_ID = c.cust_ID and p.address = 'London'  
    having a.Balance > 1000
    
    
 --   Find Customers who are availing loan and how much
    Select  p.* 
    From Person p , Customer c , Loan l 
    where p.Person_ID = c.Cust_ID and l.loan_ID = c.Loan_ID
    Group by p.Person_ID
    
    
 --   Find Customers who are availing loan and how much along with amount and where it is used 
    Select  p.* , l.Amount , l.Type
    From Person p , Customer c , Loan l 
    where p.Person_ID = c.Cust_ID and l.loan_ID = c.Loan_ID

    
    
 --   List the employees who work in Bank of England Branch 
    Select Employee_ID 
    from Employee 
    where Branch_Code in (Select Branch_Code from Branch where address = 'England') 
    
    
 --   List the account that has interest rate greater than 3 
    select * from Account where Interest_ID in (Select Interest_ID from Interest where Rate > 3)
    
 --    Get All Banks that are located in London
    DELIMITER //
    CREATE PROCEDURE GetBank()
    BEGIN
	SELECT *  FROM Bank where Address = 'London';
    END //
    DELIMITER ;
    
    call GetBank()
    
    
    
 --   Get Accounts that are saving accounts
     DELIMITER //
    CREATE PROCEDURE GetSavingAccount()
    BEGIN
	SELECT a.* 
    From Account a, Account_Type t
    where t.Acc_Type_Code = a.Acc_Type_Code and t.Description like '%Saving%';
    END //
    DELIMITER ;
    
    call GetSavingAccount();
    
    
    Update the Bank  address;
    Update Bank 
    set address = 'Washinton DC'
    where BCode = 'B101';

    Update the interest rate that has interest less than 5
    Update Interest  
    set Rate = 10
    where Interest_ID = 61
    

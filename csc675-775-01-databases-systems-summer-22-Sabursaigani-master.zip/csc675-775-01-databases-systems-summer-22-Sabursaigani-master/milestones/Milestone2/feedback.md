# The grader will add your feedback for milestone 2 here.
* Only 12 Business requirements.
* Implementation of queries are missing lots of requirements. 

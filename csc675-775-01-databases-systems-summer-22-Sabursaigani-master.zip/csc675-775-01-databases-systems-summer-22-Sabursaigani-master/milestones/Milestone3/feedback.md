# The grader will add your feedback for milestone 3 here.
* Not all 16 requirements are implemented. 
* No command is giving any output. 

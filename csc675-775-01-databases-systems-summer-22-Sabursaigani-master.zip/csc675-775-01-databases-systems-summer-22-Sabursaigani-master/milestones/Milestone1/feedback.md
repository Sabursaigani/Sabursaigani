# The grader will add your feedback for milestone 1 in this file.
* Section III : There are many missing entities in the db requirements. 
* Section IV : Only 12 strong entities. 
* Section V : ERD is missing a lot of requirements. 

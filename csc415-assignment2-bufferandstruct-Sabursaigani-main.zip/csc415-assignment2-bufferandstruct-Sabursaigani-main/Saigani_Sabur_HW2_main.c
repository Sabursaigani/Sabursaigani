/**************************************************************
* Class:  CSC041502-S22R-5812
* Name: Sabur Saigani
* Student ID: 921794806
* GitHub UserID: Sabursaigani
* Project: Assignment 2 – Stucture in Memory and Buffering
*
* File: Saigani_Sabur_HW2_main.c
*
* Description:This assignment is to write a C program that accepts arguments via the command line and then
displays each of those arguments to the terminal along with how many arguments there are.
In this assignment, I had to write a C program that accepted 3 command arguments, and those
were used to initialize a dynamically allocated struct and then data was extract from some
function and saved to buffer, which was committed when full. At the end, I had to understand
the output that was coming from compiled functionality and analyze it.
*
**************************************************************/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "assignment2.h"

int main(int argc, char const *argv[])
{
    // creating struct (dynamic allocation)
    personalInfo* info = malloc(sizeof(personalInfo));

    // populating
    info->firstName = argv[1];
    info->lastName = argv[2];
    info->studentID = 921794806;
    info->level = SENIOR;
    info->languages = KNOWLEDGE_OF_JAVA | KNOWLEDGE_OF_C | KNOWLEDGE_OF_MIPS_ASSEMBLER;
    strcpy(info->message, argv[3]);

    // writing using writePersonalInfo function.
    int result = writePersonalInfo(info);   

    // checking if success or not.
    if (result == 0)
    {
        printf("writePersonalInfo returns success!\n");
    }
    else
    {
        printf("writePersonalInfo returns failure!!!\n");
    }

    // block with block size.
    char block[BLOCK_SIZE];
    char* returned = getNext();

    // getting data from getNext function (till not null)
    int currentIndex = 0;
    while (returned != NULL)
    {   
        // copying data to buffer block.
        int i = 0;
        for (i = 0; i < strlen(returned); i++)
        {
            block[currentIndex++] = returned[i];

            // if full commit.
            if (currentIndex == 256)
            {
                commitBlock(block);
                currentIndex = 0;
                strcpy(block, "");
            }
        }

        returned = getNext();
    }

    if (currentIndex != 0)
    {
        commitBlock(block);
    }

    // deallocating allocated info struct.
    free(info);

    // final output call and returning it's return value.
    return checkIt();
}



